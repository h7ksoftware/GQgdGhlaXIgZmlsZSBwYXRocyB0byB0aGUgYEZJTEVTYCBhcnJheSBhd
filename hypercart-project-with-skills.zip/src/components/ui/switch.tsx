import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/switch.tsx");import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;

let prevRefreshReg;
let prevRefreshSig;

if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react-swc can't detect preamble. Something is wrong."
    );
  }

  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/app/src/components/ui/switch.tsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}

import { jsxDEV as _jsxDEV } from "/@id/__x00__jsx-source/jsx-dev-runtime";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7dd7a232"; const React = ((m) => m?.__esModule ? m : { ...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {}, default: m })(__vite__cjsImport3_react);
import * as SwitchPrimitives from "/node_modules/.vite/deps/@radix-ui_react-switch.js?v=7dd7a232";
import { cn } from "/src/lib/utils.ts";
const Switch = /*#__PURE__*/ React.forwardRef(_c = ({ className, ...props }, ref)=>/*#__PURE__*/ _jsxDEV(SwitchPrimitives.Root, {
        className: cn("peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors data-[state=checked]:bg-primary data-[state=unchecked]:bg-input focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50", className),
        ...props,
        ref: ref,
        children: /*#__PURE__*/ _jsxDEV(SwitchPrimitives.Thumb, {
            className: cn("pointer-events-none block h-5 w-5 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0")
        }, void 0, false, {
            fileName: "/app/src/components/ui/switch.tsx",
            lineNumber: 18,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "/app/src/components/ui/switch.tsx",
        lineNumber: 10,
        columnNumber: 3
    }, this));
_c1 = Switch;
Switch.displayName = SwitchPrimitives.Root.displayName;
export { Switch };
var _c, _c1;
$RefreshReg$(_c, "Switch$React.forwardRef");
$RefreshReg$(_c1, "Switch");


if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}


if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/app/src/components/ui/switch.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/app/src/components/ui/switch.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN3aXRjaC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgKiBhcyBTd2l0Y2hQcmltaXRpdmVzIGZyb20gXCJAcmFkaXgtdWkvcmVhY3Qtc3dpdGNoXCI7XG5cbmltcG9ydCB7IGNuIH0gZnJvbSBcIkAvbGliL3V0aWxzXCI7XG5cbmNvbnN0IFN3aXRjaCA9IFJlYWN0LmZvcndhcmRSZWY8XG4gIFJlYWN0LkVsZW1lbnRSZWY8dHlwZW9mIFN3aXRjaFByaW1pdGl2ZXMuUm9vdD4sXG4gIFJlYWN0LkNvbXBvbmVudFByb3BzV2l0aG91dFJlZjx0eXBlb2YgU3dpdGNoUHJpbWl0aXZlcy5Sb290PlxuPigoeyBjbGFzc05hbWUsIC4uLnByb3BzIH0sIHJlZikgPT4gKFxuICA8U3dpdGNoUHJpbWl0aXZlcy5Sb290XG4gICAgY2xhc3NOYW1lPXtjbihcbiAgICAgIFwicGVlciBpbmxpbmUtZmxleCBoLTYgdy0xMSBzaHJpbmstMCBjdXJzb3ItcG9pbnRlciBpdGVtcy1jZW50ZXIgcm91bmRlZC1mdWxsIGJvcmRlci0yIGJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uLWNvbG9ycyBkYXRhLVtzdGF0ZT1jaGVja2VkXTpiZy1wcmltYXJ5IGRhdGEtW3N0YXRlPXVuY2hlY2tlZF06YmctaW5wdXQgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLXJpbmcgZm9jdXMtdmlzaWJsZTpyaW5nLW9mZnNldC0yIGZvY3VzLXZpc2libGU6cmluZy1vZmZzZXQtYmFja2dyb3VuZCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgZGlzYWJsZWQ6b3BhY2l0eS01MFwiLFxuICAgICAgY2xhc3NOYW1lLFxuICAgICl9XG4gICAgey4uLnByb3BzfVxuICAgIHJlZj17cmVmfVxuICA+XG4gICAgPFN3aXRjaFByaW1pdGl2ZXMuVGh1bWJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwicG9pbnRlci1ldmVudHMtbm9uZSBibG9jayBoLTUgdy01IHJvdW5kZWQtZnVsbCBiZy1iYWNrZ3JvdW5kIHNoYWRvdy1sZyByaW5nLTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZGF0YS1bc3RhdGU9Y2hlY2tlZF06dHJhbnNsYXRlLXgtNSBkYXRhLVtzdGF0ZT11bmNoZWNrZWRdOnRyYW5zbGF0ZS14LTBcIixcbiAgICAgICl9XG4gICAgLz5cbiAgPC9Td2l0Y2hQcmltaXRpdmVzLlJvb3Q+XG4pKTtcblN3aXRjaC5kaXNwbGF5TmFtZSA9IFN3aXRjaFByaW1pdGl2ZXMuUm9vdC5kaXNwbGF5TmFtZTtcblxuZXhwb3J0IHsgU3dpdGNoIH07XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJTd2l0Y2hQcmltaXRpdmVzIiwiY24iLCJTd2l0Y2giLCJmb3J3YXJkUmVmIiwiY2xhc3NOYW1lIiwicHJvcHMiLCJyZWYiLCJSb290IiwiVGh1bWIiLCJkaXNwbGF5TmFtZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxZQUFZQSxXQUFXLFFBQVE7QUFDL0IsWUFBWUMsc0JBQXNCLHlCQUF5QjtBQUUzRCxTQUFTQyxFQUFFLFFBQVEsY0FBYztBQUVqQyxNQUFNQyx1QkFBU0gsTUFBTUksVUFBVSxNQUc3QixDQUFDLEVBQUVDLFNBQVMsRUFBRSxHQUFHQyxPQUFPLEVBQUVDLG9CQUMxQixRQUFDTixpQkFBaUJPLElBQUk7UUFDcEJILFdBQVdILEdBQ1Qsc1hBQ0FHO1FBRUQsR0FBR0MsS0FBSztRQUNUQyxLQUFLQTtrQkFFTCxjQUFBLFFBQUNOLGlCQUFpQlEsS0FBSztZQUNyQkosV0FBV0gsR0FDVDs7Ozs7Ozs7Ozs7O0FBS1JDLE9BQU9PLFdBQVcsR0FBR1QsaUJBQWlCTyxJQUFJLENBQUNFLFdBQVc7QUFFdEQsU0FBU1AsTUFBTSxHQUFHIn0=